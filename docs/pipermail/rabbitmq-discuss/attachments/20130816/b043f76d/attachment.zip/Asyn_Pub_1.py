import Asyn_Pub_class
import sys

msg = 'hi'

    # Connect to localhost:5672 as guest with the password guest and virtual host "/" (%2F)
conn = Asyn_Pub_class.Publisher('mqserver10', 5672, 'guest', 'guest')
    
    
try:
    conn.run('1', 'direct', '1', '1')
except KeyboardInterrupt:
        conn.stop()

