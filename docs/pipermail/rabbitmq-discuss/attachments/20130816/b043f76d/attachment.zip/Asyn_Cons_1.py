import Asyn_Cons_class

    # Connect to localhost:5672 as guest with the password guest and virtual host "/" (%2F)
C1 = Asyn_Cons_class.Consumer('mqserver10', 5672, 'guest', 'guest')
try:
    C1.run('1', 'direct', '1', '1')
except KeyboardInterrupt:
    C1.stop()

