﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RabbitMQ.Client;
using System.Threading;

namespace rabbitMQsimple
{
  class Program
  {
    private const int MESSAGES_PER_SECOND= 6000;
    private const string AMPQ_SERVER = "localhost";
    private const string TRADES_EX = "trades";

    static IModel m_TradeChannel;
    static IBasicProperties m_basicProperties;
    static Timer tradeTimer;

    static bool m_KeepRunning = true;
    static void Main(string[] args)
    {
      IConnection rabbitConnect = new ConnectionFactory().CreateConnection(AMPQ_SERVER);
      m_TradeChannel = rabbitConnect.CreateModel();

      m_basicProperties = m_TradeChannel.CreateBasicProperties();
      m_basicProperties.AppId = "TradePublish";
      m_basicProperties.DeliveryMode = 1;
      m_basicProperties.Expiration = "10000";

      tradeTimer = new Timer(PushData, "", 1000, 1000);

      Console.ReadLine();
      m_KeepRunning = false;
    }

    private static void PushData(object state) 
    {
      if (!m_KeepRunning)
        return;

      System.Text.ASCIIEncoding encode = new ASCIIEncoding();
      for (int i = 0; i < MESSAGES_PER_SECOND; i++) 
      {
        
        string message = string.Format("{0} - {1}", DateTime.Now.ToLongTimeString(), i);
        m_TradeChannel.BasicPublish(TRADES_EX,"", m_basicProperties, encode.GetBytes(message));
      }
      Console.WriteLine("finished publishing messages : {0}", DateTime.Now.ToLongTimeString());
    }
  }
}
