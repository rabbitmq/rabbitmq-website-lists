﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using RabbitMQ.Client;
using RabbitMQ.Client.MessagePatterns;
using RabbitMQ.Client.Events;

namespace Consumer
{
  class Program
  {
    static BackgroundWorker messageAccept = new BackgroundWorker();
    const string AMPQ_SERVER = "localhost";
    const string TRADES_EX = "trades";
    const int MESSAGES_PER_SECOND = 6000;

    static void Main(string[] args)
    {
      Console.WriteLine("starting consumer program");

      messageAccept.DoWork += new DoWorkEventHandler(messageAccept_DoWork);
      messageAccept.RunWorkerAsync();

      Console.ReadLine();

    }

    static void messageAccept_DoWork(object sender, DoWorkEventArgs e)
    {
      System.Text.ASCIIEncoding encode = new ASCIIEncoding();
      char[] seperators = new char[]{'-'};
      using (IConnection conn = new ConnectionFactory().CreateConnection(AMPQ_SERVER)) 
      {
        using (IModel channel = conn.CreateModel()) 
        {
          Subscription sub = new Subscription(channel, TRADES_EX, "direct", "");
          foreach (BasicDeliverEventArgs ev in sub) 
          {
            string message = encode.GetString(ev.Body);
            int number = Int32.Parse(message.Split(seperators)[1].Trim());
            if(number > MESSAGES_PER_SECOND -2)
              Console.WriteLine(message);
            sub.Ack(ev);
          }
        }
      }
    }
  }
}
