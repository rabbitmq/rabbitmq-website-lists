using System;
using System.Collections.Generic;
using System.Text;

using RabbitMQ.Client;
using RabbitMQ.Client.Content;
using RabbitMQ.Client.Events;
using RabbitMQ.Util;

namespace RabbitMQTestPublish {
	class Program {
		static void SendMessage(IModel ch, ushort ticket) {
			MapMessageBuilder mapMessageBuilder = new MapMessageBuilder(ch);
			mapMessageBuilder.Properties.DeliveryMode = 2;

			mapMessageBuilder.Body["type"] = 1;
			mapMessageBuilder.Body["version"] = 1;
			mapMessageBuilder.Body["param1"] = "abcd";
			mapMessageBuilder.Body["param2"] = "abcd";
			mapMessageBuilder.Body["sent"] = DateTime.UtcNow.ToString();

			ch.BasicPublish(ticket, string.Empty, string.Empty, mapMessageBuilder.GetContentHeader() as IBasicProperties, mapMessageBuilder.GetContentBody());

			Console.WriteLine("Sent!");
		}
				
		static void Main(string[] args) {
			string userName = "put username here";
			string password = "put password here";
			string virtualHost = "put virtual host here";
			
			string serverName = "localhost";
			string queueName = "ActionsQueue";

			ConnectionFactory factory = new ConnectionFactory();
			factory.Parameters.UserName = userName;
			factory.Parameters.Password = password;
			factory.Parameters.VirtualHost = virtualHost;
			factory.Parameters.RequestedHeartbeat = 0;

			IConnection connection = factory.CreateConnection(serverName);
			try {
				IModel ch = connection.CreateModel();				
				ushort ticket = ch.AccessRequest("/data");
				ch.QueueBind(ticket, queueName, string.Empty, string.Empty, false, null);

				string s = null;
				while (s != "q") {
					Console.WriteLine("Press '1' and 'Enter' to send an item or 'q' to quit:");
					s = Console.ReadLine();
					if (!string.IsNullOrEmpty(s)) {
						s = s.Trim().ToLower();

						switch (s) {
							case "1":
								SendMessage(ch, ticket);
								break;
							default:
								break;
						}
					}
				}
			}
			finally {				
				connection.Close();
			}
		}
	}
}
