using System;
using System.Collections.Generic;
using System.Text;

using RabbitMQ.Client;
using RabbitMQ.Client.Content;
using RabbitMQ.Client.Events;
using RabbitMQ.Util;

namespace RabbitMQTestConsume {
	class Program {
		static void Main(string[] args) {
			string userName = "put username here";
			string password = "put password here";
			string virtualHost = "put virtual host here";
			
			string serverName = "localhost";
			string queueName = "ActionsQueue";

			ConnectionFactory factory = new ConnectionFactory();
			factory.Parameters.UserName = userName;
			factory.Parameters.Password = password;
			factory.Parameters.VirtualHost = virtualHost;
			factory.Parameters.RequestedHeartbeat = 0;

			IConnection connection = factory.CreateConnection(serverName);
			try {
				IModel ch = connection.CreateModel();
				ushort ticket = ch.AccessRequest("/data");
				ch.QueueBind(ticket, queueName, string.Empty, string.Empty, false, null);

				BasicGetResult result = null;
				MapMessageReader mapMessageReader = null;

				Console.WriteLine("Started!");
				while (true) {
					result = ch.BasicGet(ticket, queueName, false);
					if (result != null) {
						ch.BasicAck(result.DeliveryTag, false);

						Console.WriteLine("Got message:");
						mapMessageReader = new MapMessageReader(result.BasicProperties, result.Body);
						Console.WriteLine(string.Format("\ttype={0}", mapMessageReader.Body["type"]));
						Console.WriteLine(string.Format("\tversion={0}", mapMessageReader.Body["version"]));
						Console.WriteLine(string.Format("\tSent={0}", mapMessageReader.Body["sent"]));
					} else {
						System.Threading.Thread.Sleep(1000);
					}
				}
			}
			finally {
				connection.Close();
			}			
		}
	}
}
