#!/usr/bin/env python

import pika, sys

# Establish connection to the broker

class Producer_1(object):

    def __init__(self, exchange_name, host, port,username, password):

        self.credentials = pika.PlainCredentials(username=username, password=password)
        self.conn_params = pika.ConnectionParameters(host=host, port=port, credentials=self.credentials)
        self.connection = pika.BlockingConnection(self.conn_params)
        self.exchange_name = exchange_name
        self.channel = self.connection.channel()


    def publish(self, message, routing_key):
    
        self.channel.confirm_delivery()
        
        msg = 'hi' 
        
        if self.channel.basic_publish(exchange=self.exchange_name,routing_key=routing_key, body='print msg', properties=pika.BasicProperties(content_type='text/plain', delivery_mode=1)):
            print 'Message publish was confirmed' 
            
        else:
            print 'Message could not be confirmed'
        
    def close(self):
        self.channel.close()
        self.connection.close()    
   


