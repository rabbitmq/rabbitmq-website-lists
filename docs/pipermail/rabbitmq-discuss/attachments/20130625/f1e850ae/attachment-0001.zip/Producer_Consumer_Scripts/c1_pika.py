import consumer_pika

C1 = consumer_pika.Consumer_1(host='localhost', port = 5670, username='guest', password='guest')

C1.declare_exchange(exchange_name='0', exchange_type = 'direct', ex_durable_flag = True, ex_auto_delete_flag = False)

C1.declare_queue(queue_name='0', routing_key='0', q_durable_flag = True, q_exclusive_flag = True, q_auto_delete_flag = False)

def callback_1(channel, method, properties, body):
   print body+'0'
   C1.channel.basic_ack(delivery_tag = method.delivery_tag)

C1.consume_init(callback_1, '0', '0')

C1.consume_start()


 

