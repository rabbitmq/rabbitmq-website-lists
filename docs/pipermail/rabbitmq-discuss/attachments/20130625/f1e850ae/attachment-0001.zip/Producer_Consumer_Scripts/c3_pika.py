import consumer_pika

C3 = consumer_pika.Consumer_1(host='localhost', port = 5670, username='guest', password='guest')

C3.declare_exchange(exchange_name='2', exchange_type = 'direct', ex_durable_flag = True, ex_auto_delete_flag = False)

C3.declare_queue(queue_name='2', routing_key='2', q_durable_flag = True, q_exclusive_flag = True, q_auto_delete_flag = False)

def callback_3(channel, method, properties, body):
   print body+'2'
   C3.channel.basic_ack(delivery_tag = method.delivery_tag)

C3.consume_init(callback_3, '2', '2')

C3.consume_start()


 

