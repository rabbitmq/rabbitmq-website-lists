import consumer_pika

C4 = consumer_pika.Consumer_1(host='localhost', port = 5670, username='guest', password='guest')

C4.declare_exchange(exchange_name='3', exchange_type = 'direct', ex_durable_flag = True, ex_auto_delete_flag = False)

C4.declare_queue(queue_name='3', routing_key='3', q_durable_flag = True, q_exclusive_flag = True, q_auto_delete_flag = False)

def callback_4(channel, method, properties, body):
   print body+'3'
   C4.channel.basic_ack(delivery_tag = method.delivery_tag)

C4.consume_init(callback_4, '3', '3')

C4.consume_start()


 

