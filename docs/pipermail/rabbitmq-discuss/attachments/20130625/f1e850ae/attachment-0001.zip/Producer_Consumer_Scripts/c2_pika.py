import consumer_pika

C2 = consumer_pika.Consumer_1(host='localhost', port = 5670, username='guest', password='guest')

C2.declare_exchange(exchange_name='1', exchange_type = 'direct', ex_durable_flag = True, ex_auto_delete_flag = False)

C2.declare_queue(queue_name='1', routing_key='1', q_durable_flag = True, q_exclusive_flag = True, q_auto_delete_flag = False)

def callback_2(channel, method, properties, body):
   print body+'1'
   C2.channel.basic_ack(delivery_tag = method.delivery_tag)

C2.consume_init(callback_2, '1', '1')

C2.consume_start()


 

