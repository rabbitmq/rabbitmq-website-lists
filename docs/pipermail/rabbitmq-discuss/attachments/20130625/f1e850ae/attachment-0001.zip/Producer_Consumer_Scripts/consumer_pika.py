#!/usr/bin/env python

import pika, sys, time


class Consumer_1(object):
    def __init__(self, host, port, username, password): 
        self.credentials = pika.PlainCredentials(username=username, password=password)
        self.conn_params = pika.ConnectionParameters(host=host, port=port, credentials=self.credentials)
        self.connection = pika.BlockingConnection(self.conn_params)
        self.channel = self.connection.channel()

    def close(self):
        self.channel.close()
        self.connection.close()    
   

    def declare_exchange(self, exchange_name, exchange_type, ex_durable_flag, ex_auto_delete_flag):
        self.exchange_name = exchange_name
        self.exchange_type = exchange_type
        self.ex_durable_flag = ex_durable_flag
        self.ex_auto_delete_flag = ex_auto_delete_flag

        self.channel.exchange_declare(exchange=self.exchange_name, type= self.exchange_type, durable=self.ex_durable_flag, auto_delete=self.ex_auto_delete_flag)
        
   
    def declare_queue(self, queue_name, q_routing_key, q_durable_flag, q_exclusive_flag, q_auto_delete_flag):
        self.queue_name = queue_name
        self.q_routing_key = q_routing_key
        self.q_durable_flag = q_durable_flag
        self.q_exclusive_flag = q_exclusive_flag
        self.q_auto_delete_flag = q_auto_delete_flag

        self.channel.queue_declare(queue=self.queue_name, durable=self.q_durable_flag, exclusive=self.q_exclusive_flag, auto_delete=self.q_auto_delete_flag)
        self.channel.queue_bind(queue=self.queue_name, exchange=self.exchange_name, routing_key=self.q_routing_key)

    
    def consume_init(self, msg_function, queue_name, consumer_tag):
	self.channel.basic_qos(prefetch_count=300)
        self.channel.basic_consume(msg_function, queue=queue_name, no_ack=False, consumer_tag=consumer_tag)
      
       
    def consume_start(self):
        self.channel.start_consuming()    
            
    def consume_stop(self, consumer_tag):
        self.channel.basic_cancel(consumer_tag)
        
        
    def wait(self):
        while True:
            self.channel.wait()    
    


