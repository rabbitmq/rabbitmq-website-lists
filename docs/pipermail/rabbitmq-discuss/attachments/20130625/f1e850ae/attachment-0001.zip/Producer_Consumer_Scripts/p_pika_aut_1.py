import random, time
import producer_pika

P = []

global messages
messages = 0 

counter = len(P)
print counter
list_of_pub = []

for i in range(0,4):
    print 'adding %d to the list' %i
    P.append(i)

counter = len(P)
print counter

list_of_prod = []



while messages < 1:

    for i in range(0,4):
        P[i] = producer_pika.Producer_1(exchange_name =str(i), host='localhost', port=5670, username='guest', password='M@cb00k123')
        list_of_prod.append(P[i])
        messages = 1

while messages > 0:
      for j in range(0,4):    
        key = str(j)
        P[j].publish(str(j), key)
  
        
   
        
        
        
       
        
