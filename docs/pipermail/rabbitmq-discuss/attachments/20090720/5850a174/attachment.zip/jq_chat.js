(function($) {
    var channel = null;
    var qName = null;

    $(document).ready(function() {
            $("#txtUsername").val(initUsername());
            $("#txtSend").focus();
            $("#btnSend").click(function() {
                    channel.basicPublish(
                                         $("#txtChannelName").val(),
                                         $("#txtUsername").val(),
                                         $("#txtSend").val(),
                                         { content_type: "text/plain" });
                    $("#txtSend").val("");
                });
            $("#btnChannel").click(function() {
                    changeChannel();
                });
            $.openRabbitChannel(function(chan) {
                    channel = chan;
                    changeChannel();
                });
        });

    var initUsername = function() {
        return "user" + Math.floor(Math.random() * 1e10);
    };
    
    var changeChannel = function() {
        var onQBound = function() {
            $("#chatoutput").html();
            channel.basicConsume(function() {},
                                 qName,
                                 function(delivery) {
                                     var msg = $("<div></div>");
                                     msg.append($("<span class='uid'></span>").text(delivery.routing_key));
                                     msg.append($("<span class='msg'></span>").text(delivery.content));
                                     $("#chatoutput").append(msg);
                                 },
                                 { no_ack: true });
        };
        var declareFreshQ = function() {
            channel.queueDeclare(function(name) {
                    qName = name;
                    channel.queueBind(onQBound,qName,$("#txtChannelName").val());
                });
        };
        var onXDeclared = function() {
            if(qName) {
                channel.queueDelete(declareFreshQ,qName);
            } else {
                declareFreshQ();
            }
        };
        channel.exchangeDeclare(onXDeclared,$("#txtChannelName").val(),{type:"fanout"});


        
    };
    
    

})(jQuery);