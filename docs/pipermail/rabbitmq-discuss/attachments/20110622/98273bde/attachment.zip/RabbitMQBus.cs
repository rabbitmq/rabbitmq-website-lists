using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMQ.Client.Exceptions;

namespace Sample
{
    public class RabbitMQBus : IDisposable
    {
        private readonly IConnection connection;

        public RabbitMQBus(string server)
        {
            var connectionFactory = new ConnectionFactory
                                        {
                                            HostName = server,
                                            UserName = "guest",
                                            Password = "guest",
                                            Protocol = Protocols.AMQP_0_9_1
                                        };
            connection = connectionFactory.CreateConnection();
        }

        public void RegisterHandler<T>(Action<T> handler, string queueName)
        {
            var jsonSerializer = new JavaScriptSerializer();
            var topicName = typeof (T).Name;
            using (var channel = connection.CreateModel())
            {
                channel.ExchangeDeclare(topicName, ExchangeType.Fanout, true);
                channel.QueueDeclare(queueName, false, false, false, null);
                channel.QueueBind(queueName, topicName, "", null);
            }
            var job = new Thread(() =>
                                     {
                                         using (var channel = connection.CreateModel())
                                         {
                                             var consumer = new QueueingBasicConsumer(channel);
                                             channel.BasicConsume(queueName, false, consumer);
                                             while (true)
                                             {
                                                 BasicDeliverEventArgs e = null;
                                                 try
                                                 {
                                                     e = (BasicDeliverEventArgs) consumer.Queue.Dequeue();
                                                     var message =
                                                         jsonSerializer.Deserialize<T>(
                                                             Encoding.UTF8.GetString(e.Body));
                                                     handler(message);
                                                     channel.BasicAck(e.DeliveryTag, false);
                                                 }
                                                 catch (EndOfStreamException)
                                                 {
                                                     break;
                                                 }
                                                 catch (OperationInterruptedException)
                                                 {
                                                     break;
                                                 }
                                                 catch (Exception ex)
                                                 {
                                                     HandleBadMessage(e, ex);
                                                     channel.BasicReject(e.DeliveryTag, true);
                                                 }
                                             }
                                         }
                                     });
            job.Start();
        }

        public void Publish<T>(T @event)
        {
            using (IModel channel = connection.CreateModel())
            {
                string topicName = typeof (T).Name;
         //       channel.ExchangeDeclare(topicName, ExchangeType.Fanout, true); // this fixed the issue
                var ser = new JavaScriptSerializer();
                string serializedForm = ser.Serialize(@event);
                IBasicProperties basicProperties = channel.CreateBasicProperties();
                channel.BasicPublish(topicName, "", false, false, basicProperties,
                                     Encoding.UTF8.GetBytes(serializedForm));
            }
        }


        public void UnregisterHandler<T>(string handlerId)
        {
            using (IModel channel = connection.CreateModel())
            {
                string topicName = typeof (T).Name;
                string queueName = handlerId;
                channel.QueueUnbind(queueName, topicName, "", null);
            }
        }

        public void PurgeQueue(string handlerId)
        {
            using (var channel = connection.CreateModel())
            {
                try
                {
                    channel.QueuePurge(handlerId);
                }
                catch (OperationInterruptedException e)
                {
                    if (e.ShutdownReason.ReplyCode != 404) throw;
                }
            }
        }

        private void HandleBadMessage(BasicDeliverEventArgs basicDeliverEventArgs, Exception exception)
        {
            Console.WriteLine(string.Format(">>> Exception handling message {0}. Exception is {1}",
                                            basicDeliverEventArgs, exception));
        }

        public void Dispose()
        {
            connection.Close();
            connection.Dispose();
        }
    }
}