using System;
using Sample.Support;
using NUnit.Framework;

namespace Sample
{
    internal class MyEvent
    {
        public string Data;
    }

    internal class YourEvent
    {
        public string Data;
    }

    [TestFixture]
    public class RabbitMQBasicMessagingTest
    {
        private RabbitMQBus bus1;

        [SetUp]
        public void Setup()
        {
            bus1 = new RabbitMQBus(Environment.GetEnvironmentVariable("RUNZ_TEST_RABBITMQ_SERVER") ?? "localhost");
        }

        [TearDown]
        public void TearDown()
        {
            bus1.Dispose();
        }

        [Test]
        public void should_be_able_to_send_messages_from_within_subscription_handlers()
        {
            var done = 0;
            const string queueId = "unit_test8";
            bus1.PurgeQueue(queueId);
            bus1.RegisterHandler<MyEvent>(ev =>
                                              {
                                                  bus1.Publish(new YourEvent {Data = "m1"});
                                                  done++;
                                                  bus1.Publish(new YourEvent {Data = "m2"});
                                                  done++;
                                                  bus1.Publish(new YourEvent {Data = "m3"});
                                                  done++;
                                              }, queueId);
            bus1.Publish(new MyEvent {Data = "unit_does_not_matter"});
            AssertionHelpers.WithRetries(() => Assert.That(done, Is.EqualTo(3)));
            bus1.UnregisterHandler<MyEvent>(queueId);
        }
    }
}