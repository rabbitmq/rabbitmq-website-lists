﻿using System;
using System.Threading;
using NUnit.Framework;

namespace Sample.Support
{
    public static class AssertionHelpers
    {

        public static void WithRetries(Action action, int retries = 100)
        {
            while (true)
            {
                try
                {
                    action();
                    return;
                }
                catch (AssertionException)
                {
                    if (retries > 0)
                    {
                        retries = SleepABit(retries);
                    }
                    else throw;
                }
            }
        }

        static int SleepABit(int retries)
        {
            retries--;
            Thread.Sleep(100);
            return retries;
        }
    }
}