﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace SharedTypes 
{
  [Serializable]
  public struct MISPrice
  {
    public const int INSTRUMENT_TYPE_EQUITY = 0x100000;
    public int ID;
    public char exch;
    public double bidPrice;
    public double askPrice;
    public double lastPrice;
    public double highPrice;
    public double lowPrice;
    public double prevClose;
    public int bidSize;
    public int askSize;
    public int lastSize;
    public long lastTime;
    public int volume;
    public int openInterest;
    public int tradeConditions;
    public int quoteConditions;
    public static int misPriceSz = Marshal.SizeOf(typeof(MISPrice));
    private static IntPtr pMISPrice = Marshal.AllocHGlobal(misPriceSz);
    public void CopyToBuffer(byte[] buffer, int startIndex)
    {
      Marshal.StructureToPtr(this, pMISPrice, false);
      Marshal.Copy(pMISPrice, buffer, startIndex, misPriceSz);
    }

    public static MISPrice CopyFromBuffer(byte[] buffer, int startIndex)
    {
      Marshal.Copy(buffer, startIndex, pMISPrice, misPriceSz);
      return (MISPrice)Marshal.PtrToStructure(pMISPrice, typeof(MISPrice));
    }

    public string Key
    {
      get
      {
        return String.Format("{0}.{1}", ID, exch);
      }
    }

    public override string ToString()
    {
      return String.Format("{0}:{1,4:0.00}-{2,4:0.00}[{3,3:0}|{4,3:0}]", exch, bidPrice, askPrice, bidSize, askSize);
    }
  }
}

