﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace SharedTypes 
{
  [Serializable]
  public struct MISQuote
  {
    public static short FLAG_NO_EFFECT = 0x0;
    public static short FLAG_CHANGES_NBBO_PRICE = 0x1;
    public static short FLAG_AFFECTS_NBBO = 0x2;
    public double bidPrice;
    public double askPrice;
    public uint bidSize;
    public uint askSize;
    public double bboBidPrice;
    public double bboAskPrice;
    public uint bboBidSize;
    public uint bboAskSize;
    public uint quoteConditions;
    public int id;
    public int seq;
    public char exchange;
    public short flags;
    public static int misQuoteSz = Marshal.SizeOf(typeof(MISQuote));

    private static int m_Sequence = 0;
    public static int GetNextSequence()
    {
      m_Sequence += 1;
      return m_Sequence;
    }

    public void CopyToBuffer(byte[] buffer, int startIndex)
    {
      IntPtr ptrIn = Marshal.AllocHGlobal(misQuoteSz);
      Marshal.StructureToPtr(this, ptrIn, false);
      Marshal.Copy(ptrIn, buffer, startIndex, misQuoteSz);
      Marshal.FreeHGlobal(ptrIn);
    }

    public static MISQuote CopyFromBuffer(byte[] buffer, int startIndex)
    {
      IntPtr ptrOut = Marshal.AllocHGlobal(misQuoteSz);
      Marshal.Copy(buffer, startIndex, ptrOut, misQuoteSz);
      MISQuote quote = (MISQuote)Marshal.PtrToStructure(ptrOut, typeof(MISQuote));
      Marshal.FreeHGlobal(ptrOut);
      return quote;
    }

    public bool IsOption
    {
      get
      {
        return (id & MISPrice.INSTRUMENT_TYPE_EQUITY) == 0;
      }
    }

    public bool AffectsNBBO
    {
      get
      {
        return (bboBidPrice >= 0 || bboAskPrice >= 0 || bboBidSize > 0 || bboAskSize > 0);
      }
    }

    public static MISQuote GetDummyQuote()
    {
      MISQuote quote = new MISQuote();
      //quote.seq = GetNextSequence();
      quote.id = 1;
      quote.bidPrice = 1;
      quote.askPrice = 2;
      quote.askSize = 10;
      quote.bidSize = 20;
      quote.exchange = 'I';
      quote.quoteConditions = (uint)1;
      return quote;
    }

    public override string ToString()
    {
      return String.Format("{0}: {1,4:0.00}-{2,4:0.00}[{3,3:0}|{4,3:0}] {5,4:0.00}-{6,4:0.00}[{7,3:0}|{8,3:0}]", exchange, bidPrice, askPrice, bidSize, askSize, bboBidPrice, bboAskPrice, bboBidSize, bboAskSize);
    }

    public string ToTickLog()
    {
      return String.Format("{0,8} {1,8}.{2,-3:000} {3,6:0.00}[{4,5}] {5,6:0.00}[{6,5}] {7,6:0.00}[{8,5}] {9,6:0.00}[{10,5}]", seq, id, (int)exchange, bidPrice, bidSize, askPrice, askSize, bboBidPrice, bboBidSize, bboAskPrice, bboAskSize);
    }
  }
}

