﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace SharedTypes 
{
  public struct MISTrade
  {
    public static int IsUptick = 0x01;

    public double lastPrice;
    public uint lastSize;
    public int tradeConditions;
    public uint volume;
    public int id;
    public int seq;
    public char exchange;
    public int flags;
    public long ticks;
    public static int misTradeSz = Marshal.SizeOf(typeof(MISTrade));

    public void CopyToBuffer(byte[] buffer, int startIndex)
    {
      IntPtr inPtr = Marshal.AllocHGlobal(misTradeSz);
      Marshal.StructureToPtr(this, inPtr, false);
      Marshal.Copy(inPtr, buffer, startIndex, misTradeSz);
      Marshal.FreeHGlobal(inPtr);
    }

    public static MISTrade CopyFromBuffer(byte[] buffer, int startIndex)
    {
      IntPtr ptrOut = Marshal.AllocHGlobal(misTradeSz);
      Marshal.Copy(buffer, startIndex, ptrOut, misTradeSz);
      MISTrade trade = (MISTrade)Marshal.PtrToStructure(ptrOut, typeof(MISTrade));
      Marshal.FreeHGlobal(ptrOut);
      return trade;
    }

    public bool IsOption
    {
      get
      {
        return (id & MISPrice.INSTRUMENT_TYPE_EQUITY) == 0;
      }
    }

    public override string ToString()
    {
      return String.Format("{0}: {1,4:0.00}[{2,3:0}]", exchange, lastPrice, lastSize);
    }

    public string ToTickLog()
    {
      return String.Format("{0,8} {1,8}.{2,-3:000} {3,6:0.00}[{4,5}]", seq, id, (int)exchange, lastPrice, lastSize);
    }

    static int m_Temp = 0;
    public static MISTrade GetDummyTrade()
    {
      m_Temp = (m_Temp == 0) ? 1 : 0;
      MISTrade trade = new MISTrade();
      trade.id = 0;
      trade.lastPrice = 1 + m_Temp;
      trade.lastSize = (uint)(2 + m_Temp);
      trade.tradeConditions = 1;
      trade.exchange = 'I';
      trade.ticks = DateTime.Now.AddHours(1).Ticks;
      return trade;
    }

    public static MISTrade GetDummyTrade1()
    {
      m_Temp = (m_Temp == 0) ? 1 : 0;
      MISTrade trade = new MISTrade();
      trade.id = 0;
      trade.lastPrice = (uint)10;
      trade.lastSize = (uint)10;
      trade.tradeConditions = 1;
      trade.exchange = 'I';
      trade.ticks = DateTime.Now.AddHours(1).Ticks;
      return trade;
    }

  }
}
