﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharedTypes
{
  public struct QuoteSymbol
  {
    public string symbol;
    public MISQuote quote;
  }

  public struct TradeSymbol
  {
    public string symbol;
    public MISTrade trade;
  }
}
