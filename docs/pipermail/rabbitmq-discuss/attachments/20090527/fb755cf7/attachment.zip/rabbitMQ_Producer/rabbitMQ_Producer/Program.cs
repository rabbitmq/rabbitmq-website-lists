﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using SharedTypes;
using RabbitMQ.Client;
using RabbitMQ.Client.Exceptions;

namespace rabbitMQ_Producer
{
  /**
   * To run this code needs to reference the RabbitMQ .NET Client
   * 
   * Metrics are taken by the GenericQueue object, when running the consumer and producer you will find
   * two files under: C:\Logs\yyyy-mm-dd\ if you tail on both the PublishQuotes.log and Incoming.log you will see
   * a lines something like this:
   * 16:22:53.810]: Quotes (I|O|H|L|C|D) 995 | 995 | 12 | 0 | 0 | 0
   * 
   * Mesurments are taken at about 10 second intervals. In the above example this quote queue accepted 995 messages in, 995 messages
   * went out and the high water mark was 12, low water =0, current = 0 and dropped =0. The queue will drop messages if objects inside
   * the queue exceed its max amount.
   * 
   * The problem I am having is that in the example below I am publishing 1000 quotes per second but I am only recieving about 1/3 of the number.
   * Where are the messages going? What am I doing wrong? Thanks for your help.
   * */
  class Program
  {
    private const int QUOTES_PER_SECOND = 1000;
    private const int TRADES_PER_SECOND = 250;
    static GenericQueue<TradeSymbol> m_TradeQueue = new GenericQueue<TradeSymbol>("Trades", 16 * 10240, 16 * 10240);
    static GenericQueue<QuoteSymbol> m_QuoteQueue = new GenericQueue<QuoteSymbol>("Quotes", 256 * 10240, 256 * 10240);
    private const string AMPQ_SERVER = "localhost";
    private const string TRADES_EX = "trades";
    private const string QUOTES_EX = "quotes";

    static IModel m_TradeChannel;
    static IModel m_QuoteChannel;
    static IBasicProperties m_basicProperties;
    static Timer quoteTimer; 
    static Timer tradeTimer;

    static bool m_KeepRunning = true;
    
    private static void CreateOutgoingLogMetrics()
    {
      Logger.Init(String.Format("C:\\Logs\\{0}",DateTime.Today.ToString("yyyy-MM-dd")),"PublishQuotes", "Queue");
    }
 
    public static void Main(string[] args)
    {
      CreateOutgoingLogMetrics();
      IConnection rabbitConnect = new ConnectionFactory().CreateConnection(AMPQ_SERVER);

      m_TradeChannel = rabbitConnect.CreateModel();
      m_QuoteChannel = rabbitConnect.CreateModel();

      m_basicProperties = m_QuoteChannel.CreateBasicProperties();
      m_basicProperties.AppId = "TradePublish";
      m_basicProperties.DeliveryMode = 1;
      m_basicProperties.Expiration = "10000";

      quoteTimer  = new Timer(PushQuoteData, "", 1000, 1000);
      tradeTimer = new Timer(PushTradeData, "", 1250, 1000);
     
      Thread drainTrades = new Thread(delegate() { DrainTrades(); });
      drainTrades.Name = "trades";
      drainTrades.Start();

      Thread drainQuotes = new Thread(delegate() { DrainQuotes(); });
      drainQuotes.Name = "quotes";
      drainQuotes.Start();

      Console.WriteLine("quotes and trades are being published");
      Console.ReadLine();

     
      m_KeepRunning = false;

    }

    private static void PushTradeData(Object data)
    {
      for (int i = 0; i < TRADES_PER_SECOND; i++) 
      {
        TradeSymbol ts = new TradeSymbol();
        ts.symbol = "AMZN";
        ts.trade = new MISTrade();
        ts.trade.exchange = 'I';
        ts.trade.lastPrice = 78.32;
        ts.trade.lastSize = 100;
        ts.trade.id = i;
        ts.trade.seq = i;
        m_TradeQueue.AddToQueue(ts);
      }
    }

    private static void PushQuoteData(Object data)
    {
      for (int i = 0; i < QUOTES_PER_SECOND; i++) 
      {
        QuoteSymbol qs = new QuoteSymbol();
        qs.symbol = "MSFT";
        qs.quote = new MISQuote();
        qs.quote.askPrice = 20.39;
        qs.quote.askPrice = 20.33;
        
        qs.quote.bidSize = (uint)i;
        qs.quote.exchange = 'A';
        qs.quote.id = i;
        qs.quote.seq = i;
        m_QuoteQueue.AddToQueue(qs);
      }
    }

    private static void DrainTrades() 
    {
      int queueSize = 128;
      byte[] packet = new byte[MISTrade.misTradeSz * queueSize];
      int i = 0;
      while (m_KeepRunning) 
      {

        TradeSymbol ts = m_TradeQueue.GetFromQueue();
        MISTrade trade = ts.trade;

        trade.CopyToBuffer(packet, i * MISTrade.misTradeSz);
        i++;

        if(i >= 10) 
        {
          try
          {
            m_TradeChannel.BasicPublish(TRADES_EX,"", m_basicProperties, packet);
          }
          catch (AlreadyClosedException ex)
          {
            Console.WriteLine("ERROR draining Trades {0}", ex);
            break;
          }
          finally 
          {
            i = 0;
          }

        }

      }
    }

    private static void DrainQuotes() 
    {
      int queueSize = 128;
      byte[] packet = new byte[MISQuote.misQuoteSz * queueSize];
      int i = 0;
      while (m_KeepRunning)
      {

        QuoteSymbol qs = m_QuoteQueue.GetFromQueue();
        MISQuote quote = qs.quote;

        quote.CopyToBuffer(packet, i * MISQuote.misQuoteSz);
        i++;

        if (i  >= 10)
        {
          try
          {
            m_QuoteChannel.BasicPublish(QUOTES_EX,"", m_basicProperties, packet);
          }
          catch (AlreadyClosedException ex)
          {
            Console.WriteLine("ERROR draining Trades {0}", ex);
            break;
          }
          finally
          {
            i = 0;
          }

        }

      }
    }
  }
}
