﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

namespace SharedTypes 
{
  /// <summary>
  /// Summary description for MessageQueue.
  /// </summary>
  public class GenericQueue<T> : Queue<T>
  {
    private int m_MessagesIn = 0;
    private int m_MessagesOut = 0;
    private int m_HighWaterMark = 0;
    private int m_LowWaterMark = Int32.MaxValue;
    private int m_Dropped = 0;
    private int m_MaxCapacity;

    private string m_Name = ""; public string Name { get { return m_Name; } set { m_Name = value; } }
    private Timer m_MeasureTimer;

    public GenericQueue(int capacity, int maxCapacity)
      : this("", capacity, maxCapacity)
    {
    }

    public GenericQueue(string name, int capacity, int maxCapacity)
      : base(capacity)
    {
      m_Name = name;
      m_MaxCapacity = maxCapacity;
      TimerCallback cb = new TimerCallback(LogMeasures);
      m_MeasureTimer = new Timer(cb, null, 1000, 10000);
    }

    public void AddToQueue(T obj)
    {
      lock (this)
      {
        if (Count >= m_MaxCapacity)
        {
          m_Dropped++;
          return;
        }

        base.Enqueue(obj);
        m_MessagesIn++;
        if (Count > m_HighWaterMark) m_HighWaterMark = Count;
        if (Count == 1)
          Monitor.Pulse(this);
      }
    }

    public T GetFromQueue()
    {
      lock (this)
      {
        if (Count == 0)
          Monitor.Wait(this, 1000);

        if (Count == 0)
          return default(T);

        m_MessagesOut++;

        if (Count - 1 < m_LowWaterMark) m_LowWaterMark = Count - 1;
        return base.Dequeue();
      }
    }

    public bool Contains(T obj)
    {
      lock (this)
      {
        return base.Contains(obj);
      }
    }

    public T QuickPeek()
    {
      lock (this)
      {
        if (Count == 0)
          Monitor.Wait(this);
        return base.Peek();
      }
    }

    public MeasureState GetStats()
    {
      MeasureState state = new MeasureState();
      lock (this)
      {
        state.MessagesIn = m_MessagesIn;
        state.MessagesOut = m_MessagesOut;
        state.QueueSize = this.Count;
        state.HighWaterMark = this.m_HighWaterMark;
        state.LowWaterMark = this.m_LowWaterMark;
        state.MessagesDropped = this.m_Dropped;


        m_MessagesIn = 0;
        m_MessagesOut = 0;
        m_HighWaterMark = 0;
        m_LowWaterMark = Int32.MaxValue;
        m_Dropped = 0;
      }
      return state;
    }

    public void LogMeasures(object cbState)
    {
      if (m_Name == "")
        return;

      MeasureState state = GetStats();
      if (state.LowWaterMark == Int32.MaxValue)
        state.LowWaterMark = 0;

      Logger.LogForType("Queue", "{0} (I|O|H|L|C|D) {1} | {2} | {3} | {4} | {5} | {6}",
        this.m_Name,
        state.MessagesIn, state.MessagesOut, state.HighWaterMark, state.LowWaterMark,
        state.QueueSize, state.MessagesDropped);
    }

    public class MeasureState
    {
      public int MessagesIn = 0;
      public int MessagesOut = 0;
      public int QueueSize = 0;
      public int HighWaterMark = 0;
      public int LowWaterMark = 0;
      public int MessagesDropped = 0;
    }
  }
}
