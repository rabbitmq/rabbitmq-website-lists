﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.ComponentModel;
using RabbitMQ.Client;
using RabbitMQ.Client.MessagePatterns;
using RabbitMQ.Client.Events;
using SharedTypes;

namespace rabbitMQ_Consumer
{
  class Program
  {
    static BackgroundWorker tradeWorker = new BackgroundWorker();
    static BackgroundWorker optionWorker = new BackgroundWorker();
    const string AMPQ_SERVER = "localhost";
    static FeedAccept feedAccept = new FeedAccept();

    static void Main(string[] args)
    {
      Console.WriteLine("Starting the client program");
      feedAccept.RunFeeds();

      tradeWorker.DoWork += new DoWorkEventHandler(tradeWorker_DoWork);
      optionWorker.DoWork += new DoWorkEventHandler(optionWorker_DoWork);
      tradeWorker.RunWorkerAsync();
      optionWorker.RunWorkerAsync();
     
      Console.ReadLine();
      feedAccept.StopFeeds();
    }

    static void optionWorker_DoWork(object sender, DoWorkEventArgs e)
    {
      using (IConnection conn = new ConnectionFactory().CreateConnection(AMPQ_SERVER))
      {
        using (IModel channel = conn.CreateModel())
        {
          Subscription sub = new Subscription(channel, "quotes", "direct", "");
          foreach (BasicDeliverEventArgs ev in sub)
          {

            int totalLength = ev.Body.Length / MISQuote.misQuoteSz;
            int index = 0;
            while (index < totalLength)
            {
              MISQuote quote = MISQuote.CopyFromBuffer(ev.Body, index);
              index += MISQuote.misQuoteSz;
              if (quote.seq != 0)
                feedAccept.OnQuote(quote);
              else
                Console.WriteLine(quote);
            }
            sub.Ack(ev);
          }
        }
      }
    }

    static void tradeWorker_DoWork(object sender, DoWorkEventArgs e)
    {
      using (IConnection conn = new ConnectionFactory().CreateConnection(AMPQ_SERVER))
      {
        using (IModel channel = conn.CreateModel())
        {

          Subscription sub = new Subscription(channel, "trades", "direct", "");
          foreach (BasicDeliverEventArgs ev in sub)
          {
            int totalLength = ev.Body.Length / MISTrade.misTradeSz;
            int index = 0;
            while (index < totalLength)
            {
              MISTrade trade = MISTrade.CopyFromBuffer(ev.Body, index);
              index += MISTrade.misTradeSz;
              //Console.WriteLine(trade.ToString());
              //if (trade.seq != 0)
              feedAccept.OnTrade(trade);
            }
            sub.Ack(ev);
          }
        }
      }
    }
  }
}
