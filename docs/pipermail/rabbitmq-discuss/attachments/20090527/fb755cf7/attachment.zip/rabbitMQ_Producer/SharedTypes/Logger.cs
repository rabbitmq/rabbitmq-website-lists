﻿using System;
using System.Collections;
using System.Text;
using System.Threading;
using System.IO;

namespace SharedTypes 
{
  /// <summary>
  /// Summary description for Logger.
  /// </summary>
  public class Logger
  {
    private StreamWriter m_sw; public StreamWriter SW { get { return m_sw; } set { m_sw = value; } }
    private static Hashtable m_Loggers = new Hashtable();

    private string m_LogDir = ""; public string LogDir { get { return m_LogDir; } set { m_LogDir = value; } }
    private string m_LogBaseName = ""; public string LogBaseName { get { return m_LogBaseName; } set { m_LogBaseName = value; } }
    private string m_LogFileName = ""; public string LogFileName { get { return m_LogFileName; } }

    public static Logger GetLogger(string logType)
    {
      if (!m_Loggers.ContainsKey(logType))
        return null;
      return (Logger)m_Loggers[logType];
    }

    public static void Init(string logDir, string logBaseName, string logType)
    {
      if (m_Loggers.ContainsKey(logType))
        return;

      if (!Directory.Exists(logDir))
        Directory.CreateDirectory(logDir);
      Logger logger = new Logger(logDir, logBaseName);
      m_Loggers[logType] = logger;
      Logger.Log("***********************************************************");
      Logger.Log("*");
      Logger.Log("* Starting log for {0}", logBaseName);
      Logger.Log("*");
      Logger.Log("***********************************************************");
    }

    public static void InitTickLoggers(string logDir)
    {
      string filename;

      try
      {
        filename = String.Format("{0}/Trades.log", logDir);
        if (File.Exists(filename))
          File.Delete(filename);
        filename = String.Format("{0}/Quotes.log", logDir);
        if (File.Exists(filename))
          File.Delete(filename);
      }
      catch (Exception e)
      {
        Logger.Log("Failed deleting tick logs. {0}", e.ToString());
      }

      Logger tradeLogger = new Logger(logDir, "Trades");
      m_Loggers["Trades"] = tradeLogger;
      Logger quoteLogger = new Logger(logDir, "Quotes");
      m_Loggers["Quotes"] = quoteLogger;
    }

    private static object syncLock = new Object();

    public static void Init(string logDir, string logBaseName)
    {
      Init(logDir, logBaseName, "Default");
    }

    public Logger(string logDir, string logBaseName)
    {
      LogDir = logDir;
      if (m_LogDir == "") m_LogDir = "./logs";
      LogBaseName = logBaseName;
      if (m_LogBaseName == "") m_LogBaseName = "Log";

      m_LogFileName = String.Format("{0}/{1}.log", m_LogDir, m_LogBaseName);
    }

    public static void Log(string formatLine, params object[] parms)
    {
      LogForType("Default", formatLine, parms);
    }

    public static void LogForType(string logType, string formatLine, params object[] parms)
    {
      LogForType(logType, String.Format(formatLine, parms));
    }

    public static void LogForType(string logType, string logLine)
    {
      if (!m_Loggers.ContainsKey(logType))
        return;

      lock (syncLock)
      {
        Logger logger = (Logger)m_Loggers[logType];
        if (logger.SW == null)
        {
          logger.SW = new StreamWriter(new FileStream(logger.LogFileName, FileMode.Append, FileAccess.Write, FileShare.ReadWrite));
          logger.SW.AutoFlush = true;
        }
        string now = DateTime.Now.ToString("HH:mm:ss.fff");
        logger.SW.WriteLine("[{0}]: {1}", now, logLine);
      }
    }

    public static void LogMISTrade(string misTrade)
    {
      Logger tradeLogger = (Logger)m_Loggers["Trades"];
      lock (syncLock)
      {
        if (tradeLogger.m_sw == null)
        {
          tradeLogger.SW = new StreamWriter(new FileStream(tradeLogger.LogFileName, FileMode.Append, FileAccess.Write, FileShare.ReadWrite));
          tradeLogger.SW.AutoFlush = true;
        }
        tradeLogger.SW.WriteLine(misTrade);
      }
    }

    public static void LogMISQuote(string misQuote)
    {
      Logger quoteLogger = (Logger)m_Loggers["Quotes"];
      lock (syncLock)
      {
        if (quoteLogger.m_sw == null)
        {
          quoteLogger.SW = new StreamWriter(new FileStream(quoteLogger.LogFileName, FileMode.Append, FileAccess.Write, FileShare.ReadWrite));
          quoteLogger.SW.AutoFlush = true;
        }
        quoteLogger.SW.WriteLine(misQuote);
      }
    }

    public static void LogError(string formatLine, params object[] parms)
    {
      LogError(String.Format(formatLine, parms));
    }

    public static void LogError(string errorLine)
    {
      string logLine = String.Format("ERROR: {0}", errorLine);
      LogForType("Default", logLine);
    }

    public void Dispose()
    {
      m_sw.Close();
    }
  }
}
