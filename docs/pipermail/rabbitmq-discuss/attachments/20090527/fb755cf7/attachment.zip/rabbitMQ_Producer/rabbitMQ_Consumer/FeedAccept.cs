﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharedTypes;
using Microsoft.Win32;
using System.Threading;


namespace rabbitMQ_Consumer
{
  public class FeedAccept
  {
    private GenericQueue<MISTrade> m_MISTradeQueue;
    private GenericQueue<MISQuote> m_MISQuoteQueue;

    private object serverRunLck = new object();
    private bool m_KeepRunning = true;

    public FeedAccept() 
    {
      Logger.Init(String.Format("C:\\Logs\\{0}", DateTime.Today.ToString("yyyy-MM-dd")),"Incoming", "Queue");
      m_MISTradeQueue = new GenericQueue<MISTrade>("Trades", 10240 * 16, 10240 * 16);
      m_MISQuoteQueue = new GenericQueue<MISQuote>("Quotes", 256 * 10240, 256 * 10240);

    }

    public void RunFeeds() 
    {
      Thread quoteThread = new Thread(delegate() { HandleMISQuote(); });
      quoteThread.Name = "quoteThread";

      Thread tradeThread = new Thread(delegate() { HandleMISTrade(); });
      tradeThread.Name = "tradeThread";

      quoteThread.Start();
      tradeThread.Start();
    }


    public void StopFeeds() 
    {
      lock (serverRunLck) 
      {
        m_KeepRunning = false;
      }
    }

    public void OnTrade(MISTrade trade) 
    {
      m_MISTradeQueue.AddToQueue(trade);
    }

    public void OnQuote(MISQuote quote) 
    {
      m_MISQuoteQueue.AddToQueue(quote);
    }

    public void HandleMISTrade() 
    {
      while (m_KeepRunning) 
      {
        MISTrade trade = m_MISTradeQueue.GetFromQueue();
        if (trade.seq == 0)
          continue;
        //Thread.Sleep(20);
        //Console.WriteLine("TRADE:: {0}",trade.ToTickLog());
      } 
    }

    public void HandleMISQuote() 
    {
      while (m_KeepRunning) 
      {
        MISQuote quote = m_MISQuoteQueue.GetFromQueue();

        if (quote.seq == 0)
          continue;
        //Thread.Sleep(20);
        //Console.WriteLine("QUOTE:: {0}", quote.ToTickLog());
      } 
    }

  }
 }

